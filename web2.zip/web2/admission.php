<?php

include 'database.php';
session_start();
if (!isset($_SESSION['studentName'])) {
    header("location:student.php");
} 

if (isset($_POST['submit'])) {
    $admissionDegree = $_POST['admissionDegree'];
    $fileName = $_FILES['upload']['name'];
    $tmpName = $_FILES['upload']['tmp_name'];
    $fileSize = $_FILES['upload']['size'];
    $ext = explode('.', $fileName);
    $fileExtension = $ext[1];
    $extChecker = ['png', 'jpg'];
    $admissionAdm = $_POST['admissionAdm'];
    move_uploaded_file($tmpName, 'upload/' . $fileName);

    $query = "INSERT INTO admission(admissionDegree,fileName,admissionAdm) VALUES('$admissionDegree','$fileName','$admissionAdm')";

    $result = mysqli_query($connection, $query) or die("query of insert is not run ");
}

session_unset();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registion Form</title>
</head>

<body>
    <h1>Admission Detial</h1>
    <table>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
            <tr>
                <td>HSSC DEGREE </td>
                <td>
                    <select name="admissionDegree" id="">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Stundent Email</td>
                <td><input type="file" name="upload" id=""></td>
            </tr>
            <tr>
                <td>HSSC DEGREE </td>
                <td>
                    <select name="admissionAdm" id="">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>

</html>