<?php


include 'database.php';
if (isset($_POST['submit'])) {
    $studentAddress = $_POST['studentAddress'];
    $studentName = $_POST['studentName'];
    $studentEmail = $_POST['studentEmail'];
    $studentPassowrd = md5($_POST['studentPassowrd']);
    $studentCnic = $_POST['studentCnic'];


    $query = "INSERT INTO student(studentName,studentEmail,studentPassowrd,studentCnic,studentAddress) VALUES('$studentName','$studentEmail','$studentPassowrd','$studentCnic','$studentAddress')";

    $result = mysqli_query($connection, $query) or die("query of insert is not run ");

    $query1 = "SELECT studentName FROM student";
    $result1 = mysqli_query($connection, $query1) or die("query is not run for result 2");
    session_start();
    while ($row = mysqli_fetch_assoc($result1)) {
        if (mysqli_num_rows($result1) > 0) {

            $_SESSION['studentName'] = $row['studentName'];
        }
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registion Form</title>
</head>

<body>
    <h1>STUDENT REGISTION FORM</h1>
    <table>
        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
            <tr>
                <td>Student Name : </td>
                <td><input type="text" name="studentName" id="" required></td>
            </tr>
            <tr>
                <td>Stundent Email</td>
                <td><input type="email" name="studentEmail" id="" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="studentPassowrd" id="" required></td>
            </tr>
            <tr>
                <td>Cnic</td>
                <td><input type="text" name="studentCnic" id="" pattern="^[0-9]{5}-[0-9]{7}-[0-9]{1}$" required></td>
            </tr>
            <tr>
                <td>Text</td>
                <td><textarea name="studentAddress" id="" cols="30" rows="10"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="submit" name="submit"></td>
            </tr>
        </form>
    </table>
</body>

</html>