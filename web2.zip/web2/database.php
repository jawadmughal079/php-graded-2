<?php

define('host', 'localhost');
define('user', 'root');
define('password', '');
define('database', 'web2');



$connection = mysqli_connect(host,user,password,database) or die("connection is query is fail");


?>